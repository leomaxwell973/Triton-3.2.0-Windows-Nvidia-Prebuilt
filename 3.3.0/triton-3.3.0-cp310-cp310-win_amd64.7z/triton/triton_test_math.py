import torch
import triton
import triton.language as tl

@triton.jit
def matmul_kernel(
    # Pointers to matrices
    a_ptr, b_ptr, c_ptr,
    # Matrix dimensions
    M, N, K,
    # Block sizes
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
):
    # Program ID
    pid = tl.program_id(0)
    
    # Block ID
    grid_m = tl.cdiv(M, BLOCK_M)
    grid_n = tl.cdiv(N, BLOCK_N)
    
    # Calculate block indices
    block_m = pid // grid_n
    block_n = pid % grid_n
    
    # Starting indices
    m_start = block_m * BLOCK_M
    n_start = block_n * BLOCK_N
    
    # Create block offsets
    offs_m = tl.arange(0, BLOCK_M)
    offs_n = tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)
    
    # Create masks to handle boundary conditions
    m_mask = offs_m[:, None] + m_start < M
    n_mask = offs_n[None, :] + n_start < N
    
    # Iterate to compute a block of the output
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    
    for k in range(0, K, BLOCK_K):
        # Load the matrices with proper masking
        a_mask = m_mask & (offs_k[None, :] + k < K)
        b_mask = n_mask & (offs_k[:, None] + k < K)
        
        # Use proper indexing for loads
        a = tl.load(a_ptr + (m_start + offs_m[:, None]) * K + (k + offs_k[None, :]), 
                   mask=a_mask, other=0.0)
        b = tl.load(b_ptr + (k + offs_k[:, None]) * N + (n_start + offs_n[None, :]), 
                   mask=b_mask, other=0.0)
        
        # Matrix multiplication
        acc += tl.dot(a, b)
    
    # Store the result with proper masking
    c_mask = m_mask & n_mask
    c_offs = (m_start + offs_m[:, None]) * N + (n_start + offs_n[None, :])
    tl.store(c_ptr + c_offs, acc, mask=c_mask)

# Test the kernel
def test_matmul():
    # Matrix dimensions (smaller for testing)
    M, N, K = 128, 128, 128
    
    # Create input matrices
    a = torch.randn((M, K), device='cuda', dtype=torch.float32)
    b = torch.randn((K, N), device='cuda', dtype=torch.float32)
    
    # Output matrix
    c_triton = torch.zeros((M, N), device='cuda', dtype=torch.float32)
    
    # Launch parameters
    BLOCK_M, BLOCK_N, BLOCK_K = 32, 32, 32
    grid = (triton.cdiv(M, BLOCK_M) * triton.cdiv(N, BLOCK_N),)
    
    # Run kernel
    matmul_kernel[grid](
        a, b, c_triton, 
        M, N, K,
        BLOCK_M, BLOCK_N, BLOCK_K
    )
    
    # Verify with PyTorch
    c_torch = torch.matmul(a, b)
    print("Max difference:", torch.max(torch.abs(c_triton - c_torch)).item())
    assert torch.allclose(c_triton, c_torch, atol=0.05, rtol=0.05)
    print("Matrix multiplication test passed!")

# Run the test
test_matmul()