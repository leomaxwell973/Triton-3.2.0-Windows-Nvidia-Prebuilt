# proton_smoke.py  –  10‑second sanity check
import torch
import triton
import triton.language as tl
import triton.profiler as proton
from typing import NamedTuple


session_id = proton.start(name="protontest", context="python")
proton.start("protontest", hook="triton")
proton.activate(session_id)
with proton.scope("test0", {"bytes": 1000}):
    with proton.scope("test1", {"bytes": 2000}):

        @triton.jit
        def simple_kernel(output, n_elements, BLOCK_SIZE: tl.constexpr):
            pid = tl.program_id(0)
            block_start = pid * BLOCK_SIZE
            offsets = block_start + tl.arange(0, BLOCK_SIZE)
            mask = offsets < n_elements
            
            # Just write a constant value
            tl.store(output + offsets, 42.0, mask=mask)
            
        def test_simple():
            # Define output tensor
            n_elements = 1024
            output = torch.zeros(n_elements, device='cuda')
            
            # Define grid
            grid = (n_elements + 128 - 1) // 128
        
            # Verify results
            expected = torch.full((n_elements,), 42.0, device='cuda')
            success = torch.allclose(output, expected)
            print(f"Test passed: {success}")
            
            return output, success
            print("CUDA available:", torch.cuda.is_available())
            print("PROTON Profiling simple Triton kernel...")
            output, success = test_simple()
            if success:
                if __name__ == "__main__":
                    print("Kernel Success, First few elements:", output[:5], "run proton-viewer on hatchet")
                
proton.finalize()
