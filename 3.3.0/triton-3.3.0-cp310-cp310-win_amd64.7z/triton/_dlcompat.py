"""
_dlcompat.py – small cross-platform shim so Python code can use
dlopen / dlsym / dlclose / dlerror the POSIX way.

* On Linux/Unix: forwards directly to libdl.
* On Windows: maps to LoadLibraryA / GetProcAddress / FreeLibrary.

Usage
-----
    from triton._dlcompat import dlopen, dlsym, dlclose, dlerror
"""

import ctypes
import os
import sys
from ctypes import util as _util


# --------------------------------------------------------------------------------------
#  Constants that POSIX code sometimes passes to dlopen.
#  We keep only the ones that show up in Triton; the values here
#  don't matter on Windows but match glibc for convenience.
# --------------------------------------------------------------------------------------
RTLD_LAZY    = 0x0001
RTLD_NOW     = 0x0002
RTLD_GLOBAL  = 0x0100
RTLD_LOCAL   = 0x0000
RTLD_NODELETE = 0x1000
RTLD_NOLOAD   = 0x0004
RTLD_DEEPBIND = 0x0008


if sys.platform != "win32":
    # -------------------------------------------------------------------------
    #  POSIX:  use the real libdl exactly as before.
    # -------------------------------------------------------------------------
    _libdl_path = _util.find_library("dl") or "libdl.so.2"
    _dl = ctypes.CDLL(_libdl_path, use_errno=True)

    dlopen  = _dl.dlopen
    dlopen.argtypes  = [ctypes.c_char_p, ctypes.c_int]
    dlopen.restype   = ctypes.c_void_p

    dlsym   = _dl.dlsym
    dlsym.argtypes   = [ctypes.c_void_p, ctypes.c_char_p]
    dlsym.restype    = ctypes.c_void_p

    dlclose = _dl.dlclose
    dlclose.argtypes = [ctypes.c_void_p]
    dlclose.restype  = ctypes.c_int

    dlerror = _dl.dlerror
    dlerror.restype  = ctypes.c_char_p

else:
    # -------------------------------------------------------------------------
    #  Windows: adapt to the Win32 loader.
    # -------------------------------------------------------------------------

    # loader calls ------------------------------------------------------------
    _LoadLibraryA   = ctypes.WinDLL("kernel32").LoadLibraryA
    _GetProcAddress = ctypes.WinDLL("kernel32").GetProcAddress
    _FreeLibrary    = ctypes.WinDLL("kernel32").FreeLibrary

    _LoadLibraryA.argtypes   = [ctypes.c_char_p]
    _LoadLibraryA.restype    = ctypes.c_void_p
    _GetProcAddress.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    _GetProcAddress.restype  = ctypes.c_void_p
    _FreeLibrary.argtypes    = [ctypes.c_void_p]
    _FreeLibrary.restype     = ctypes.c_int

    # very simple thread-local “last error” store
    _last_error = ctypes.c_char_p(None)

    def dlopen(path: bytes | str, flags: int = RTLD_NOW) -> ctypes.c_void_p:
        """
        dlopen(path, flags) → handle (void*)
        Only RTLD_GLOBAL vs LOCAL matters to LoadLibrary; others are ignored.
        """
        if isinstance(path, str):
            path = os.fsencode(path)
        h = _LoadLibraryA(path)
        if not h:
            _last_error.value = f"LoadLibraryA failed on {path!r}".encode()
        return h

    def dlsym(handle: ctypes.c_void_p, symbol: bytes | str) -> ctypes.c_void_p:
        if isinstance(symbol, str):
            symbol = symbol.encode()
        addr = _GetProcAddress(handle, symbol)
        if not addr:
            _last_error.value = f"GetProcAddress failed on {symbol!r}".encode()
        return addr

    def dlclose(handle: ctypes.c_void_p) -> int:      # returns 0 on success
        ok = _FreeLibrary(handle)
        if not ok:
            _last_error.value = b"FreeLibrary failed"
        return 0 if ok else -1

    def dlerror() -> bytes | None:                    # mimic libdl semantics
        err, _last_error.value = _last_error.value, None
        return err


# ---------------------------------------------------------------------------
#  Helper: expose POSIX name so   import ctypes, dl   still works if someone
#  does “import dlopen as dl” elsewhere.  (Optional – can remove if unwanted.)
# ---------------------------------------------------------------------------
sys.modules.setdefault(__name__.rsplit(".", 1)[0] + ".dl", sys.modules[__name__])
