
import triton
import triton.language as tl
import torch

@triton.jit
def add_one_kernel(x_ptr, n_elements, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(axis=0)
    block_start = pid * BLOCK_SIZE
    offsets = block_start + tl.arange(0, BLOCK_SIZE)
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask, other=0.)
    x = x + 1
    tl.store(x_ptr + offsets, x, mask=mask)

def test_simple():
    n = 1_000_003
    x = torch.arange(n, dtype=torch.float32, device='cuda')
    y_expected = x + 1
    BLOCK_SIZE = 128
    grid = lambda meta: (triton.cdiv(n, meta['BLOCK_SIZE']),)
    add_one_kernel[grid](x, n, BLOCK_SIZE=BLOCK_SIZE)
    if torch.allclose(x, y_expected):
        print("✅ Simple add‑one kernel passed")
        return True
    else:
        print("❌ Simple add‑one kernel failed")
        return False

if __name__ == "__main__":
    test_simple()
