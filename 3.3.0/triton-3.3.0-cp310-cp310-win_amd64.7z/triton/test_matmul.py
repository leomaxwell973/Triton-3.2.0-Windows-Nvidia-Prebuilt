
import triton
import triton.ops as tops
import torch

def test_matmul():
    m, n, k = 128, 256, 64
    a = torch.randn((m, k), device='cuda', dtype=torch.float16)
    b = torch.randn((k, n), device='cuda', dtype=torch.float16)
    c_triton = tops.matmul(a, b)  # uses Triton's default matmul autotuner
    c_torch = torch.matmul(a, b)
    if torch.allclose(c_triton.float(), c_torch.float(), atol=1e-2, rtol=1e-2):
        print("✅ Matmul kernel passed")
        return True
    else:
        print("❌ Matmul kernel failed")
        return False

if __name__ == "__main__":
    test_matmul()
