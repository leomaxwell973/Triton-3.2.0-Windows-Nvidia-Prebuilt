#ifndef PROTON_DRIVER_GPU_HIP_H_
#define PROTON_DRIVER_GPU_HIP_H_

#include "Driver/Device.h"

// This is a stub header to make compilation work on Windows
// where HIP support is not expected to be available

namespace proton {

namespace hip {

// Stub implementation for Windows compatibility
#ifdef _WIN32
inline Device getDevice(uint64_t index) {
    throw std::runtime_error("HIP is not supported on Windows");
    return Device(); // Never reached, just to satisfy compiler
}
#else
// On non-Windows platforms, the real implementation should be used
Device getDevice(uint64_t index);
#endif

} // namespace hip

} // namespace proton

#endif // PROTON_DRIVER_GPU_HIP_H_