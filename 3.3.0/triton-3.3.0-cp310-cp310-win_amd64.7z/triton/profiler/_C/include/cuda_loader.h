//# Add to the top of proton/csrc/include/cuda_loader.h
#ifndef CUDA_LOADER_H
#define CUDA_LOADER_H
#endif

#include <Windows.h>
#include <cuda.h>
#include <cupti.h>
#define CUDA_DLL  "nvcuda.dll"
#define CUPTI_DLL "cupti64_12.dll"  // adjust for toolkit major


HMODULE hDrv = LoadLibraryA(CUDA_DLL);
HMODULE hCupti = LoadLibraryA(CUPTI_DLL);
