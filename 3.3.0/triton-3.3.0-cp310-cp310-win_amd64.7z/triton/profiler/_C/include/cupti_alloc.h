//# Add to the top of proton/csrc/include/cupti_alloc.h
#ifndef CUPTI_ALLOC_H
#define CUPTI_ALLOC_H
#endif
#include <Windows.h>
#ifdef _MSC_VER
  #include <malloc.h>
  #define aligned_alloc(al,sz) _aligned_malloc((sz),(al))
  #define aligned_free(ptr)    _aligned_free(ptr)
#else
  #define aligned_free(ptr)    free(ptr)
#endif
