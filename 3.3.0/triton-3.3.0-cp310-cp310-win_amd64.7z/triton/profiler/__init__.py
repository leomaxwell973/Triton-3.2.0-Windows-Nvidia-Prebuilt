# ruff: noqa
from .scope import scope, cpu_timed_scope, enter_scope, exit_scope
from .state import state, enter_state, exit_state
from .profile import (
    start,
    activate,
    deactivate,
    finalize,
    profile,
    DEFAULT_PROFILE_NAME,
)
from . import context

# Add to triton/profiler/__init__.py

# Add bundled DLLs to search path on Windows
import os, pathlib, sys
if sys.platform == "win32":
    dll_dir = pathlib.Path(__file__).parent.parent / "bin"
    if dll_dir.exists():
        os.add_dll_directory(str(dll_dir))

