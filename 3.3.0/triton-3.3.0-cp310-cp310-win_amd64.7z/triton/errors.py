"""Base class for all errors raised by Triton"""


class TritonError(Exception):
    ...
