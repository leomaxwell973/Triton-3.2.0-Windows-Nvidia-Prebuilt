# content of conftest.py


def pytest_configure(config):
    config.addinivalue_line(
        "markers", "interpreter: indicate whether interpreter supports the test"
    )
